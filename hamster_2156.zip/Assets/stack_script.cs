﻿using UnityEngine;
using System.Collections;

public class stack_script : MonoBehaviour {

    private SpriteRenderer spriteRenderer;

    public Sprite stack0;
    public Sprite stack1;
    public Sprite stack2;
    public Sprite stack3;
    public Sprite stack4;
    public Sprite stack5;
    public Sprite hams1;
    public Sprite hams2;
    public Sprite hams3;
    public Sprite hams4;
    public Sprite hams5;

    public GameObject pop;
    public GameObject push;

    // Use this for initialization
    void Start () {

        pop.SetActive(false);
        push.SetActive(false);

        spriteRenderer = GetComponent<SpriteRenderer>(); // we are accessing the SpriteRenderer that is attached to the Gameobject

        if (spriteRenderer.sprite == null) // if the sprite on spriteRenderer is null then
            spriteRenderer.sprite = stack5; // set the sprite to sprite
    }
	
	// Update is called once per frame
	void Update () {
	    if(push.activeSelf == true)
        {
            if (spriteRenderer.sprite == stack4)
                spriteRenderer.sprite = stack5;
            else if (spriteRenderer.sprite == stack3)
                spriteRenderer.sprite = stack4;
            else if (spriteRenderer.sprite == stack2)
                spriteRenderer.sprite = stack3;
            else if (spriteRenderer.sprite == stack1)
                spriteRenderer.sprite = stack2;
            else if (spriteRenderer.sprite == stack0)
                spriteRenderer.sprite = stack1;

            push.SetActive(false);
        }
        if (pop.activeSelf == true)
        {
            if (spriteRenderer.sprite == stack5)
                spriteRenderer.sprite = stack4;
            else if (spriteRenderer.sprite == stack4)
                spriteRenderer.sprite = stack3;
            else if (spriteRenderer.sprite == stack3)
                spriteRenderer.sprite = stack2;
            else if (spriteRenderer.sprite == stack2)
                spriteRenderer.sprite = stack1;
            else if (spriteRenderer.sprite == stack1)
                spriteRenderer.sprite = stack0;

            pop.SetActive(false);
        }
    }
}
